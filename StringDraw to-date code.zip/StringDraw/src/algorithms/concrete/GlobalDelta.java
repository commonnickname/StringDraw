package algorithms.concrete;

import algorithms.variants.fitness.FitnessDelta;
import algorithms.variants.greedy.GreedyGlobal;

public class GlobalDelta extends LocalDelta{
	public static String name = "Global Delta";
	
	public GlobalDelta() {
		super();
	}
	
	@Override
	protected void setupFitnessAndStrategy() {
		greedy = new GreedyGlobal(this);
		fitness = new FitnessDelta(this);
	}
}
