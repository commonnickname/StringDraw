package algorithms.concrete;

import algorithms.variants.fitness.FitnessDeltaLog;
import algorithms.variants.greedy.GreedyGlobal;

public class GlobalDeltaLog extends LocalDelta{
	public static String name = "Global Delta Logarithmic";
	
	public GlobalDeltaLog() {
		super();
	}
	
	@Override
	protected void setupFitnessAndStrategy() {
		greedy = new GreedyGlobal(this);
		fitness = new FitnessDeltaLog(this);
	}
}
