package algorithms.concrete;

import algorithms.DrawingAlgorithm;
import algorithms.variants.fitness.FitnessDeltaLog;
import algorithms.variants.greedy.GreedyLocal;

public class LocalDeltaLog extends DrawingAlgorithm{
	public static String name = "Local Delta Logarithmic";

	
	public LocalDeltaLog() {
		super();
	}
	
	protected void setupFitnessAndStrategy() {
		greedy = new GreedyLocal(this);
		fitness = new FitnessDeltaLog(this);
	}
}
