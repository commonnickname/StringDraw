package algorithms.concrete;

import algorithms.variants.fitness.FitnessNaive;
import algorithms.variants.greedy.GreedyGlobal;

public class GlobalNaive extends LocalNaive{
	public static String name = "Global Naive";
	
	public GlobalNaive() {
		super();
	}

	@Override
	protected void setupFitnessAndStrategy() {
		greedy = new GreedyGlobal(this);
		fitness = new FitnessNaive(this);
	}
}
