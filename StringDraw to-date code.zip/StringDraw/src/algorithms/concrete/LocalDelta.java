package algorithms.concrete;

import algorithms.DrawingAlgorithm;
import algorithms.variants.fitness.FitnessDelta;
import algorithms.variants.greedy.GreedyLocal;

public class LocalDelta extends DrawingAlgorithm{
	public static String name = "Local Delta";

	
	public LocalDelta() {
		super();
	}
	
	protected void setupFitnessAndStrategy() {
		greedy = new GreedyLocal(this);
		fitness = new FitnessDelta(this);
	}
}
