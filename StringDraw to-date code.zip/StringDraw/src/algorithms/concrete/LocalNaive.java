package algorithms.concrete;

import algorithms.DrawingAlgorithm;
import algorithms.variants.fitness.FitnessNaive;
import algorithms.variants.greedy.GreedyLocal;

public class LocalNaive extends DrawingAlgorithm{
	public static String name = "Local Naive";
	
	public LocalNaive() {
		super();
	}

	protected void setupFitnessAndStrategy() {
		greedy = new GreedyLocal(this);
		fitness = new FitnessNaive(this);
	}
	

}
