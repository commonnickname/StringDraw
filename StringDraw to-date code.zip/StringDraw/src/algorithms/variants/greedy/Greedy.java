package algorithms.variants.greedy;

import utils.datatypes.CLine;

public interface Greedy {
	CLine getLine();
}




