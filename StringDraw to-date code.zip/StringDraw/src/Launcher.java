import java.util.ArrayList;

import utils.datatypes.LineTable;
import utils.datatypes.PixelLine;
import windowComponents.MainWindow;

public class Launcher{
	public static void main(String[] args) {
		/*
		try {
	        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
	    } catch (Exception e) {e.printStackTrace();     }
	    */
		MainWindow frame = new MainWindow();
		/*
		LineTable lt = new LineTable(10);
		ArrayList<PixelLine> pla = lt.getIntersctingLines(new PixelLine(1, 8));
		//for(PixelLine pl: pla) System.out.println(pl.toString());
		pla.forEach(System.out::println);
		*/
	}
}

