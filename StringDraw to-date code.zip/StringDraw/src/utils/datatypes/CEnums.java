package utils.datatypes;

public class CEnums {
	public enum Mode { SINGLE, OPTIMIZATION }
	public enum Action { FIRST, NEXT, CONNECT, ODD }
}
