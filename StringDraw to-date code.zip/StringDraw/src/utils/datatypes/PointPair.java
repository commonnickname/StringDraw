package utils.datatypes;

public class PointPair {
	public Point p1;
	public Point p2;
	
	public PointPair(Point p1, Point p2) {
		this.p1 = p1;
		this.p2 = p2;
	}
}
